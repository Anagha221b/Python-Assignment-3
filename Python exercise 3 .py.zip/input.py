while True:
    user_input = input(":")
    if user_input.lower() == 'done':
        print("Done")
        break
    else:
        print(user_input)
