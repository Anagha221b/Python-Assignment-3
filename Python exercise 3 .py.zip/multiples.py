
def find_multiples(number, count):
    multiples = []
    for i in range(1, count + 1):
        multiples.append(number * i)
    return multiples

number = int(input("Enter a number: "))
count = int(input("Enter how many multiples you want: "))

print(f"The first {count} multiples of {number} are: {find_multiples(number, count)}")
